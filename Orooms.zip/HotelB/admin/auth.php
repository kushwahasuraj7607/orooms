<?php
$username = "root";
$password = "";
$hostname = "localhost"; 
$db = "oroom";

//connection to the database
$dbhandle = mysqli_connect($hostname, $username, $password,$db) ;
 

//select a database to work 
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
};


?>